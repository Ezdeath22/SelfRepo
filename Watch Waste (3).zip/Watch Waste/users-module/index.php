<div id="third-submenu">
   

<div id="subcontent">
    <?php
      switch($action){
                case 'create':
                    require_once 'users-module/create-admin.php';
                break; 
                case 'modify':
                    require_once 'users-module/modify-admin.php';
                break; 
                case 'profile':
                    require_once 'users-module/view-profile1.php';
                break;
                case 'result':
                    require_once 'users-module/search-user.php';
                break;
                default:
                    require_once 'users-module/main.php';
                break; 
            }
    ?>
  </div>