
<div id="subcontent">
    <table id="data-list">
<a> List of Admins </a>
      <tr>
        <th>#</th>
        <th>Name</th>

        <th>Email</th>
 
      </tr>
<?php
$count = 1;
$count = 1;
if($admin->list_admin() != false){
foreach($admin->list_admin() as $value){
   extract($value);
  
?>
      <tr>
        <td><?php echo $count;?></td>
        <td><a href="index.php?page=settings&subpage=admin&action=profile&id=<?php echo $admin_id;?>"><?php echo $admin_lastname.', '.$admin_firstname;?></a></td>

        <td><?php echo $admin_email;?></td>
      </tr>
      <tr>
<?php
 $count++;
}
}else{
  echo "No Record Found.";
}
?>
    </table>
</div>