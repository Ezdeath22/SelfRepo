<div id="third-submenu">

<div id="subcontent">
    <?php

  
      switch($action){
                case 'create':
                    require_once 'users-module/create-user.php';
                break; 
                case 'modify':
                    require_once 'users-module/modify-user.php';
                break; 
                case 'profile':
                    require_once 'users-module/view-profile.php';
                break;
                case 'result':
                    require_once 'users-module/search-user.php';
                break;
                case 'join_zone':
                    require_once 'users-module/User-Profile.php';
                break;
                default:
                 
                    require_once 'users-module/main1.php';
                break; 
            }
    ?>
  </div>
