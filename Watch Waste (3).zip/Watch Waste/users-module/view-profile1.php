<h3>Provide the Required Information</h3>
<div id="form-block">
<form method="POST" action="processes/process.admin.php?action=update">
        <div id="form-block-half">
            <label for="fname">First Name</label>
            <input type="text" id="fname" class="input" name="firstname" value="<?php echo $admin->get_admin_firstname($id);?>" placeholder="Your name..">

            <label for="lname">Last Name</label>
            <input type="text" id="lname" class="input" name="lastname" value="<?php echo $admin->get_admin_lastname($id);?>" placeholder="Your last name..">

      
        </div>
        <div id="form-block-half">
            <label for="status">Account Status</label>
          
            <label for="email">Email</label>
            <input type="email" id="email" class="input" name="email" value="<?php echo $admin->get_admin_email($id);?>" placeholder="Your email..">
        
            
            <input type="hidden" id="adminid" name="adminid" value="<?php echo $id;?>"/>
          
       
               
            <?php
            
            ?>
            
        </div>
        <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
        <div id="button-block">
        <input type="submit" value="Update">
        </div>
        
</form>
<form method="POST" action="processes/process.admin.php?action=delete">
    <input type="hidden" id="adminid" name="adminid" value="<?php echo $id; ?>"/>
    <div id="button-block">
        <input type="submit" value="Delete Account" onclick="return confirm('Are you sure you want to delete your account? This action cannot be undone.');">
    </div>
</form>
</div>