<div id="second-submenu">
    <a href="index.php?page=settings&subpage=admin">Admin</a> |
    <a href="index.php?page=settings&subpage=users">Users</a> |
</div>
<div id="content">
    <?php
      switch($subpage){
                case 'admin':
                    require_once 'users-module/index.php';
                break; 
                case 'users':
                    require_once 'users-module/index1.php';
                break; 
                case 'module_xxx':
                    require_once 'module-folder/';
                break; 
                default:
                    require_once 'main.php';
                break; 
            }
    ?>
  </div>