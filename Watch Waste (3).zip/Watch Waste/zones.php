<?php
/* include the class file (global - within application) */
include_once 'classes/class.user.php';
include 'config/config.php';

$page = (isset($_GET['page']) && $_GET['page'] != '') ? $_GET['page'] : '';
$subpage = (isset($_GET['subpage']) && $_GET['subpage'] != '') ? $_GET['subpage'] : '';
$action = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : '';
$id = (isset($_GET['id']) && $_GET['id'] != '') ? $_GET['id'] : '';

$user = new User(); // Instantiate the User class here

if(!$user->get_session()){
	header("location: login.php");
}
$user_id = $user->get_user_id($_SESSION['user_email']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Masskara Unofficial</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Assistant&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="zone1-modules/custom.css?<?php echo time();?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="Styles.css">

</head>
<body>

<div id="header">
    <img src="watchwaste.png" style="width: 100px; height: auto; position: relative; top: -40px;">
</div>

<div id="wrapper">
  <div id="menu">
      <a href="index.php">Home</a> | 
      <a href="index.php?page=zone1">Zone 1</a> | 
      <a href="index.php?page=zone2">Zone 2</a> |
      <a href="index.php?page=zone3">Zone 3</a> |
      <a href="index.php?page=zone4">Zone 4</a> |
      <a href="index.php?page=settings">Settings</a> 
      <a href="logout.php" class="move-right">Log Out</a> |
      <span class="move-right"><?php echo $user->get_user_lastname($user_id).', '.$user->get_user_firstname($user_id);?>&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;</span> 
</div>

  <div id="content">
<?php
    switch($page){
        case 'settings':
            require_once 'settings-module/index.php';
            break; 
        case 'zone1':
            require_once 'zone1-modules/index.php';
            break; 
        case 'zone2':
            require_once 'zone2-modules/index.php';
            break; 
        case 'zone3':
            require_once 'zone3-modules/index.php';
            break; 
        case 'zone4':
            require_once 'zone4-modules/index.php';
            break;
        default:
            // Assuming main.php will be your main content file
            require_once 'main.php';
            break; 
    }
?>

<?php
for ($zoneId = 1; $zoneId <= 4; $zoneId++) {
    $zoneName = $user->getZoneName($zoneId);
    $zoneDescription = $user->getZoneDescription($zoneId);
?>
<br>
<br>
<br>
<br>
<br>
<br>
    <!-- HTML code with dynamic data -->
    <div class="row featurette">
        <?php if ($zoneId % 2 == 1) { // For Zone 1 and Zone 3 (odd zoneId), start on the left side ?>
            <div class="col-md-7">
                <h2 class="featurette-heading fw-normal lh-1"><?php echo $zoneName; ?><br>
                  
                <p class="lead"><?php echo $zoneDescription; ?></p>
            </div>
            <div class="col-md-5 featurette-image-container">
                <img src="Hanz1.jpg" alt="Image <?php echo $zoneId; ?>" class="featurette-image img-fluid mx-auto">
            </div>
        <?php } else { // For Zone 2 and Zone 4 (even zoneId), start on the right side ?>
            <div class="col-md-5 featurette-image-container">
                <img src="images/BCDMasskara.png" alt="Image <?php echo $zoneId; ?>" class="featurette-image img-fluid mx-auto">
            </div>
            <div class="col-md-7">
                <h2 class="featurette-heading fw-normal lh-1"><?php echo $zoneName; ?><br>
                    
                <p class="lead"><?php echo $zoneDescription; ?></p>
            </div>
        <?php } ?>
    </div>

    <hr class="featurette-divider">
    
<?php } ?>
</div>
</div>

</body>
</html>
