<div id="second-submenu">
    <a href="index.php?page=zone4&subpage=zone4">Person In Charge</a> |
   
</div>
<div id="content">
    <?php
      switch($subpage){
                case 'zone4':
                    require_once 'zone4-modules/main.php';
                break; 
            }
    ?>
    <?php
require_once 'classes/class.user.php';
$user = new User();
?>
  </div>
  <!DOCTYPE html>
<html>
<head>
    <title>Your Application Name</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Assistant&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <canvas id="myChart"></canvas>
    <label>Select Label:</label>
    <input type="radio" name="selectedLabel" value="January" checked> January
    <input type="radio" name="selectedLabel" value="February"> February
    <input type="radio" name="selectedLabel" value="March"> March
    <input type="radio" name="selectedLabel" value="April"> April
    <input type="radio" name="selectedLabel" value="May"> May
    <input type="radio" name="selectedLabel" value="June"> June

    <button onclick="increaseData()">Increase Data</button>
    <button onclick="decreaseData()">Decrease Data</button>

    <script>
        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart;

        function updateChart(newData) {
            myChart.data.datasets[0].data = newData;
            myChart.update();
        }

        function increaseData() {
            // Get the selected label from the radio buttons
            var selectedLabel = document.querySelector('input[name="selectedLabel"]:checked').value;

            // Find the index of the selected label in the array
            var labelIndex = myChart.data.labels.indexOf(selectedLabel);

            // Increase the data for the selected label
            if (labelIndex !== -1) {
                myChart.data.datasets[0].data[labelIndex]++;
                myChart.update();
            }
        }

        function decreaseData() {
            // Get the selected label from the radio buttons
            var selectedLabel = document.querySelector('input[name="selectedLabel"]:checked').value;

            // Find the index of the selected label in the array
            var labelIndex = myChart.data.labels.indexOf(selectedLabel);

            // Decrease the data for the selected label (with a minimum value of 0)
            if (labelIndex !== -1 && myChart.data.datasets[0].data[labelIndex] > 0) {
                myChart.data.datasets[0].data[labelIndex]--;
                myChart.update();
            }
        }

        myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['January', 'February', 'March', 'April', 'May', 'June'],
                datasets: [{
                    label: 'Sales',
                    data: [50, 19, 3, 5, 2, 3],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }]
                }
            }
        });
    </script>
</body>
</html>
