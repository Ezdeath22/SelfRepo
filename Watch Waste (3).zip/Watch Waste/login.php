<?php
session_start();

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    // Include your User class or any authentication logic
    include 'classes/class.admin.php';

    $admin = new admin();  // Assuming User is your authentication class
    //var_dump($_POST);
    $adminemail = $_POST['adminemail'];
    $adminpassword = $_POST['password'];

    // Check login credentials
    if ($admin->check_loginadmin($adminemail, $adminpassword)) {
        // Successful login
        $_SESSION['login'] = true;
        $_SESSION['admin_email'] = $adminemail;
        header('Location: index.php');  // Redirect to your dashboard or another page
        exit();
    } else {
        // Failed login
        echo '<script>alert("Invalid login credentials. Please try again.");</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login As Admin</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Assistant&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
    <style>
        body {
            background-image: url('image/trash1.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            font-family: 'Assistant', sans-serif;
            margin: 0;
            padding: 0;
        }

        #brand-block {
            text-align: center;
            padding: 20px;
        }

        #login-block {
            max-width: 400px;
            margin: 0 auto;
            background: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);
        }

        #login-block img {
            width: 150px;
            height: auto;
            display: block;
            margin: 0 auto;
        }

        .input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            box-sizing: border-box;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            box-sizing: border-box;
            background-color: #32373d;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        a {
            color: #32373d;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
        
    </style>
</head>
<body>
    <div id="brand-block">
      
    </div>
    <div id="login-block">
        <center>
          <h2>Hello Admin </h2>
    </center>
        <form method="POST" action="" name="login">
            <img src="watchwaste.png" alt="Watch Waste">
            <div>
                <input type="email" class="input" required name="adminemail" placeholder="Valid E-mail"/>
            </div>
            <div>
                <input type="password" class="input" required name="password" placeholder="Password"/>
            </div>
            <div>
                <input type="submit" name="submit" value="Login"/>
            </div>
            <p>Don't Have Account? Please <a href="signup.php">Sign Up</a></p>
            <p>Log In as <a href="users/login.php">User</a></p>
        </form>
    </div>
</body>
</html>
