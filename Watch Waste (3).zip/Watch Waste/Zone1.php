<!DOCTYPE html>
<html>
<head>
    <title>Zone 1</title>
</head>
<body>
    <h1>Welcome to Zone 1</h1>
    <!-- Add more content here -->
</body>
</html>
