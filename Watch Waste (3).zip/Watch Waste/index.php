<?php
/* include the class file (global - within application) */
include_once 'classes/class.admin.php';
include_once 'classes/class.user.php';
include 'config/config.php';

$page = (isset($_GET['page']) && $_GET['page'] != '') ? $_GET['page'] : '';
$subpage = (isset($_GET['subpage']) && $_GET['subpage'] != '') ? $_GET['subpage'] : '';
$action = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : '';
$id = (isset($_GET['id']) && $_GET['id'] != '') ? $_GET['id'] : '';

$admin = new admin(); 
$user = new User(); 
if(!$admin->get_sessionadmin()){
	header("location: login.php");
}
$admin_id = $admin->get_admin_id($_SESSION['admin_email']);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Watch Waste</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Assistant&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css?<?php echo time();?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet"/>
   
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="css/style.css">
        <style>
    #content {
        margin: 100px;
    }
    
</style>
</head>
<body>
<div id="header" style="background-color: #32373d; padding: 50px; text-align: center; margin: 0; color: white; margin-right: 0;">
    <h1 style="margin: 0;"><img src="watchwaste.png" style="width: 200px; height: auto; position: relative; top: -110px;"> </h1>
</div>
<div class="wrapper d-flex align-items-stretch">

<nav id="sidebar" style="margin-top: -20px;">
				<div class="custom-menu">
					<button type="button" id="sidebarCollapse" class="btn btn-primary">
	        </button>
        </div>
        <div id="header">
     <a> &nbsp; WELCOME TO  <img src="watchwaste.png" style="width: 100px; height: auto; position: relative; top: -15px;"> <a>
    </div>
    <br>
	  		<div class="img bg-wrap text-center py-4" style="background-image: url(image/trash1.jpg);">
	  			<div class="user-logo">
                  <div class="img">
    <img src="<?php echo ($admin->get_admin_gender($admin_id) == 'male') ? 'image/male.png' : 'image/female.png'; ?>" style="width: 100px; height: 100px; margin-right: 10px;">
</div>
	  				<h3>  <?php echo $admin->get_admin_lastname($admin_id).', '.$admin->get_admin_firstname($admin_id);?>
    </h3>
	  			</div>
	  		</div>
        <ul class="list-unstyled components mb-5">
          <li class="active">
            <a href="index.php"><span class="fa fa-home mr-3"></span> Home</a>
          </li>
   


          <li>
            <a href="index.php?page=settings"><span class="fa fa-cog mr-3"></span> Settings</a>
          </li>
          
        
          <li>
            <a href="aboutus.php"><span class="fa fa-support mr-3"></span> About Us</a>
          </li>
          <li>
            <a href="logout.php"><span class="fa fa-sign-out mr-3"></span> Sign Out</a>
          </li>
        </ul>

    	</nav>

  <div id="content">
<?php
    switch($page){
        case 'settings':
            require_once 'settings-module/index.php';
            break; 
        case 'zone1':
            require_once 'zone1-modules/index.php';
            break; 
        case 'zone2':
            require_once 'zone2-modules/index.php';
            break; 
        case 'zone3':
            require_once 'zone3-modules/index.php';
            break; 
        case 'zone4':
            require_once 'zone4-modules/index.php';
            break;
        default:
            // Assuming main.php will be your main content file
            require_once 'main.php';
            break; 
    }
   
    
    

    if ($page !== 'zone1' && $page !== 'zone2' && $page !== 'zone3' && $page !== 'zone4' && $page !== 'settings') {
        // Display the additional content only if not on Zone 1, Zone 2, Zone 3, or Zone 4
        for ($zoneId = 1; $zoneId <= 4; $zoneId++) {
            $zoneName = $admin->getZoneName($zoneId);
            $zoneDescription = $admin->getZoneDescription($zoneId);
    
            $imgSrc = "";
            $zoneLink = "";
    
            switch ($zoneId) {
                case 1:
                    $imgSrc = "DC1.jpg";
                    $zoneLink = "index.php?page=zone1";
                    break;
                case 2:
                    $imgSrc = "DC2.jpg";
                    $zoneLink = "index.php?page=zone2";
                    break;
                case 3:
                    $imgSrc = "DC3.jpg";
                    $zoneLink = "index.php?page=zone3";
                    break;
                case 4:
                    $imgSrc = "Terra Nova.jpg";
                    $zoneLink = "index.php?page=zone4";
                    break;
            }
            
            ?>
            <!-- HTML code with dynamic data -->
            <div class="row featurette">
                <?php if ($zoneId == 2 || $zoneId == 4) : ?>
                    <!-- Zone 2 and Zone 4 -->
                    <div class="col-md-7">
                        <h2 class="featurette-heading fw-normal lh-1"><?php echo $zoneName; ?><br><br><br>
                            <p class="lead"><?php echo $zoneDescription; ?></p>
                        </div>
                        <div class="col-md-5 featurette-image-container">
                            <a href="<?php echo $zoneLink; ?>">
                                <img src="<?php echo $imgSrc; ?>" alt="Image <?php echo $zoneId; ?>" class="featurette-image img-fluid mx-auto">
                            </a>
                        </div>
                <?php else : ?>
                    <!-- Other zones -->
                    <div class="col-md-5 featurette-image-container">
                        <a href="<?php echo $zoneLink; ?>">
                            <img src="<?php echo $imgSrc; ?>" alt="Image <?php echo $zoneId; ?>" class="featurette-image img-fluid mx-auto">
                        </a>
                    </div>
                    <div class="col-md-7">
                        <h2 class="featurette-heading fw-normal lh-1"><?php echo $zoneName; ?><br><br><br>
                            <p class="lead"><?php echo $zoneDescription; ?></p>
                        </div>
                <?php endif; ?>
            </div>
            <hr style="height: 20px; background-color: #32373d;"> <!-- Add a horizontal line after each zone description -->
        <?php
        }
    }
    ?>
    </div>
    
    
    

</div>
</div>
<script src="js/jquery.min.js"></script>
    <script src="js/popper.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
<script src="jscript/script.js"></script>
</body>
</html>
