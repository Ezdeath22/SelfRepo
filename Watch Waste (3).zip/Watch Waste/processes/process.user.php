<?php
include '../classes/class.user.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch($action){
	case 'new':
        create_new_user();
	break;
    case 'update':
        update_user();
	break;
    case 'deactivate':
        deactivate_user();
	break;
    case 'delete':
        delete_user();
	break;
}
function delete_user(){
    $user = new User();
    $user_id = $_POST['userid'];
    $result = $user->delete_user($user_id);
    if($result){
        // Redirect or display a message after successful deletion
        header('location: ../index.php?message=Account%20deleted%20successfully');
    } else {
        // Handle deletion failure
        // You can display an error message or redirect to an error page
        echo "Failed to delete account";
    }
}
function create_new_user(){
    $user = new User();
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $lastname = isset($_POST['lastname']) ? ucwords($_POST['lastname']) : '';
    $firstname = isset($_POST['firstname']) ? ucwords($_POST['firstname']) : '';
    $access = isset($_POST['access']) ? ucwords($_POST['access']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $confirmpassword = isset($_POST['confirmpassword']) ? $_POST['confirmpassword'] : '';
    
    // Check if 'email' is set in $_POST
    if (empty($email)) {
        echo '<script>alert("Email is required.");</script>';
        // Handle the error as needed
        return;
    }
    if ($password !== $confirmpassword) {
        echo '<script>alert("Passwords do not match.");</script>';
        // Handle the error as needed
        return;
    }
    // Check if the email already exists
    if ($user->email_exists($email)) {
        echo '<script>alert("Email is already taken. Please choose a different email.");</script>';
        // You may also redirect the user or handle this situation differently if needed
    } else {
        // Email is not taken, proceed with user creation
        $result = $user->new_user($email, $password, $lastname, $firstname, $access);
        if ($result) {
            $id = $user->get_user_id($email);
            header('location: ../index.php?page=settings&subpage=users&action=profile&id='.$id);
        }
    }
}

function update_user(){
	$user = new User();
    $user_id = $_POST['userid'];
    $lastname = ucwords($_POST['lastname']);
    $email = ucwords($_POST['email']);
    $firstname = ucwords($_POST['firstname']);
    $access = ucwords($_POST['access']);
    $area = ucwords($_POST['area']);
   
    
    $result = $user->update_user($lastname, $email, $firstname,$access, $area, $user_id);
    if($result){
        header('location: ../index.php?page=settings&subpage=users&action=profile&id='.$user_id);
    }
}



function deactivate_user(){
	$user = new User();
    $user_id = $_POST['userid']; 
    $result = $user->deactivate_user($user_id);
    if($result){
        header('location: ../index.php?page=settings&subpage=users&action=profile&id='.$user_id);
    }
    function delete_user(){
        $user = new User();
        $user_id = $_POST['userid'];
        $result = $user->delete_user($user_id);
        if($result){
            // Redirect or display a message after successful deletion
            header('location: ../index.php?message=Account%20deleted%20successfully');
        } else {
            // Handle deletion failure
            // You can display an error message or redirect to an error page
            echo "Failed to delete account";
        }
    }
    
}
