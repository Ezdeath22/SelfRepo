<?php

class admin
{
    private $DB_SERVER = 'localhost';
    private $DB_USERNAME = 'root';
    private $DB_PASSWORD = '';
    private $DB_DATABASE = 'db_wbapp';
    private $conn;

    public function __construct()
    {
        $this->conn = new PDO("mysql:host=" . $this->DB_SERVER . ";dbname=" . $this->DB_DATABASE, $this->DB_USERNAME, $this->DB_PASSWORD);
    }

    public function new_admin($adminemail, $hashedpassword, $adminlastname, $adminfirstname, $admingender)
{
    $data = [
        [$adminlastname, $adminfirstname, $adminemail, $hashedpassword, $admingender],
    ];
    $stmt = $this->conn->prepare("INSERT INTO tbl_admin (admin_lastname, admin_firstname, admin_email, admin_password_hash, admin_gender) VALUES (?,?,?,?,?)");
    
    try {
        $this->conn->beginTransaction();
        foreach ($data as $row) {
            $stmt->execute($row);
        }
        $this->conn->commit();
    } catch (Exception $e) {
        $this->conn->rollback();
        throw $e;
    }

    return true;
}

    public function list_admin()
		{
			$sql="SELECT * FROM tbl_admin";
			$q = $this->conn->query($sql) or die("failed!");
			while($r = $q->fetch(PDO::FETCH_ASSOC))
			{
			   $data[]=$r;
			}
			if(empty($data))
			{
			   return false;
			}else
			{
				return $data;	
			}
	    }
        public function list_users()
		{
			$sql="SELECT * FROM tbl_users";
			$q = $this->conn->query($sql) or die("failed!");
			while($r = $q->fetch(PDO::FETCH_ASSOC))
			{
			   $data[]=$r;
			}
			if(empty($data))
			{
			   return false;
			}else
			{
				return $data;	
			}
	    }

        public function get_admin_id($adminemail)
        {
            $sql = "SELECT admin_id FROM tbl_admin WHERE admin_email = :email";
            $q = $this->conn->prepare($sql);
            $q->execute(['email' => $adminemail]); // Change 'email' to 'admin_email'
            $admin_id = $q->fetchColumn();
            return $admin_id;
        }

    public function get_admin_email($adminid)
    {
        $sql = "SELECT admin_email FROM tbl_admin WHERE admin_id = :id";
        $q = $this->conn->prepare($sql);
        $q->execute(['id' => $adminid]);
        $adminemail = $q->fetchColumn();
        return $adminemail;
    }

    public function get_admin_firstname($id)
    {
        $sql = "SELECT admin_firstname FROM tbl_admin WHERE admin_id = :id";
        $q = $this->conn->prepare($sql);
        $q->execute(['id' => $id]);
        $adminfirstname = $q->fetchColumn();
        return $adminfirstname;
    }

    public function get_admin_lastname($id)
    {
        $sql = "SELECT admin_lastname FROM tbl_admin WHERE admin_id = :id";
        $q = $this->conn->prepare($sql);
        $q->execute(['id' => $id]);
        $adminlastname = $q->fetchColumn();
        return $adminlastname;
    }
    public function get_admin_gender($admin_id)
    {
        $sql = "SELECT admin_gender FROM tbl_admin WHERE admin_id = :id";
        $q = $this->conn->prepare($sql);
        $q->execute(['id' => $admin_id]);
        $admin_gender = $q->fetchColumn();
        return $admin_gender;
    }
    public function delete_admin($admin_id)
    {
        $sql = "DELETE FROM tbl_admin WHERE admin_id = :admin_id";
        $stmt = $this->conn->prepare($sql);
        $stmt->bindParam(':admin_id', $admin_id);
        return $stmt->execute();
    }

    public function update_admin($adminlastname, $adminemail, $adminfirstname, $adminid)
    {
        /* Setting Timezone for DB */
        $sql = "UPDATE tbl_admin SET admin_firstname=:admin_firstname,admin_lastname=:admin_lastname,admin_email=:admin_email WHERE admin_id=:admin_id";

        $q = $this->conn->prepare($sql);
        $q->execute(array(':admin_firstname' => $adminfirstname, ':admin_lastname' => $adminlastname, ':admin_email' => $adminemail, ':admin_id' => $adminid));
        return true;
    }

    public function check_loginadmin($adminemail,$hashedpassword)
    {
        
        $sql = "SELECT * FROM tbl_admin WHERE admin_email = :email"; 
        $q = $this->conn->prepare($sql);
        $q->execute(['email' => $adminemail ]); 
        while($r = $q->fetch(PDO::FETCH_ASSOC))
        { 
           if(password_verify($hashedpassword, $r['admin_password_hash']))
           {
                $_SESSION['login']=true;
                $_SESSION['admin_email']=$adminemail;
                return true; 
           }
           else
           {
                return false;
           }
        }
           
            
    }	
    
  
    public function get_sessionadmin()
    {
        if (isset($_SESSION['login']) && $_SESSION['login'] == true) {
            return true;
        } else {
            return false;
        }
    }

    public function email_exists($adminemail)
    {
        // Assuming you have a database connection, replace 'tbl_users' with your actual table name
        $query = "SELECT COUNT(*) FROM tbl_admin WHERE admin_email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $adminemail);
        $stmt->execute();

        // Fetch the count
        $count = $stmt->fetchColumn();

        // Return true if email exists, false otherwise
        return $count > 0;
    }

	public function getZoneName($zoneId) 
		{
			$sql = "SELECT zone_name FROM zones WHERE zone_id = :zone_id";
			$stmt = $this->conn->prepare($sql);
			$stmt->bindParam(':zone_id', $zoneId);
			$stmt->execute();
			$zoneName = $stmt->fetchColumn();
			return $zoneName;
		}
		
		public function getZoneDescription($zoneId)
		{
			$sql = "SELECT description FROM zones WHERE zone_id = :zone_id";
			$stmt = $this->conn->prepare($sql);
			$stmt->bindParam(':zone_id', $zoneId);
			$stmt->execute();
			$description = $stmt->fetchColumn();
			return $description;
		}

}
