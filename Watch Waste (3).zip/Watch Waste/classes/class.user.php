<?php
	class User
	{
		private $DB_SERVER='localhost';
		private $DB_USERNAME='root';
		private $DB_PASSWORD='';
		private $DB_DATABASE='db_wbapp';
		private $conn;
		public function __construct()
		{
			$this->conn = new PDO("mysql:host=".$this->DB_SERVER.";dbname=".$this->DB_DATABASE,$this->DB_USERNAME,$this->DB_PASSWORD);
			
		}
		public function delete_user($user_id)
		{
			$sql = "DELETE FROM tbl_users WHERE user_id = :user_id";
			$stmt = $this->conn->prepare($sql);
			$stmt->bindParam(':user_id', $user_id);
			return $stmt->execute();
		}
		public function new_user($email, $hashedPassword, $lastname, $firstname, $access, $usergender)

{
    /* Setting Timezone for DB */


    $data = [[$lastname, $firstname, $email, $hashedPassword, '1', $access, $usergender]];

    $stmt = $this->conn->prepare("INSERT INTO tbl_users (user_lastname, user_firstname, user_email, user_password_hash, user_status, user_access, user_gender) VALUES (?,?,?,?,?,?,?)");

    try {
        $this->conn->beginTransaction();
        foreach ($data as $row) {
            $stmt->execute($row);
        }
        $this->conn->commit();
    } catch (Exception $e) {
        $this->conn->rollback();
        throw $e;
    }

    return true;
}

		public function email_exists($email)
		{
			// Assuming you have a database connection, replace 'tbl_users' with your actual table name
			$query = "SELECT COUNT(*) FROM tbl_users WHERE user_email = :email";
			$stmt = $this->conn->prepare($query);
			$stmt->bindParam(':email', $email);
			$stmt->execute();
	
			// Fetch the count
			$count = $stmt->fetchColumn();
	
			// Return true if email exists, false otherwise
			return $count > 0;
		}
		
			// ... other methods ...

		
			public function update_user($lastname, $email, $firstname, $access, $area, $id)
			{
				/* Setting Timezone for DB */
				$sql = "UPDATE tbl_users SET user_firstname=:user_firstname, user_lastname=:user_lastname, user_email=:user_email, user_area=:user_area, user_user_access=:user_access WHERE user_id=:user_id";
			
				$q = $this->conn->prepare($sql);
				$q->execute(array(':user_firstname' => $firstname, ':user_lastname' => $lastname, ':user_email' => $email, ':user_area' => $area, ':user_access' => $access, ':user_id' => $id));
				return true;
			}
			
		public function list_users()
		{
			$sql="SELECT * FROM tbl_users";
			$q = $this->conn->query($sql) or die("failed!");
			while($r = $q->fetch(PDO::FETCH_ASSOC))
			{
			   $data[]=$r;
			}
			if(empty($data))
			{
			   return false;
			}else
			{
				return $data;	
			}
	    }
		

		function get_user_id($email)
		{
			$sql="SELECT user_id FROM tbl_users WHERE user_email = :email";	
			$q = $this->conn->prepare($sql);
			$q->execute(['email' => $email]);
			$user_id = $q->fetchColumn();
			return $user_id;
		}
		function get_user_email($id)
		{
			$sql="SELECT user_email FROM tbl_users WHERE user_id = :id";	
			$q = $this->conn->prepare($sql);
			$q->execute(['id' => $id]);
			$user_email = $q->fetchColumn();
			return $user_email;
		}
		function get_user_firstname($id)
		{
			$sql="SELECT user_firstname FROM tbl_users WHERE user_id = :id";	
			$q = $this->conn->prepare($sql);
			$q->execute(['id' => $id]);
			$user_firstname = $q->fetchColumn();
			return $user_firstname;
		}
		function get_user_lastname($id)
		{
			$sql="SELECT user_lastname FROM tbl_users WHERE user_id = :id";	
			$q = $this->conn->prepare($sql);
			$q->execute(['id' => $id]);
			$user_lastname = $q->fetchColumn();
			return $user_lastname;
		}
		function get_user_access($id)
		{
			$sql="SELECT user_access FROM tbl_users WHERE user_id = :id";	
			$q = $this->conn->prepare($sql);
			$q->execute(['id' => $id]);
			$user_access = $q->fetchColumn();
			return $user_access;
		}

		function get_user_status($id)
		{
			$sql="SELECT user_status FROM tbl_users WHERE user_id = :id";	
			$q = $this->conn->prepare($sql);
			$q->execute(['id' => $id]);
			$user_status = $q->fetchColumn();
			return $user_status;
		}
		function get_session(){
			if(isset($_SESSION['login']) && $_SESSION['login'] == true){
				return true;
			}else{
				return false;
			}
		}
		function get_user_area($id)
		{
			$sql="SELECT user_area FROM tbl_users WHERE user_id = :id";	
			$q = $this->conn->prepare($sql);
			$q->execute(['id' => $id]);
			$user_area = $q->fetchColumn();
			return $user_area;
		}
		public function check_login($email, $password)
{
    $sql = "SELECT user_password_hash FROM tbl_users WHERE user_email = :email";
    $q = $this->conn->prepare($sql);
    $q->execute(['email' => $email]);
    $result = $q->fetch(PDO::FETCH_ASSOC);

    if ($result && password_verify($password, $result['user_password_hash'])) {
        $_SESSION['login'] = true;
        $_SESSION['user_email'] = $email;
        return true;
    } else {
        return false;
    }
}
		public function getZoneName($zoneId) 
		{
			$sql = "SELECT zone_name FROM zones WHERE zone_id = :zone_id";
			$stmt = $this->conn->prepare($sql);
			$stmt->bindParam(':zone_id', $zoneId);
			$stmt->execute();
			$zoneName = $stmt->fetchColumn();
			return $zoneName;
		}
		
		public function getZoneDescription($zoneId)
		{
			$sql = "SELECT description FROM zones WHERE zone_id = :zone_id";
			$stmt = $this->conn->prepare($sql);
			$stmt->bindParam(':zone_id', $zoneId);
			$stmt->execute();
			$description = $stmt->fetchColumn();
			return $description;
		}

		public function getObeserverName($observerId) 
		{
			$sql = "SELECT observer_name FROM observer WHERE oberserver_id = :observer_id";
			$stmt = $this->conn->prepare($sql);
			$stmt->bindParam(':observer_id', $observerId);
			$stmt->execute();
			$observerName = $stmt->fetchColumn();
			return $observerName;
		}
		
		public function getObserverEmail($observerId)
		{
			$sql = "SELECT oberserver_email FROM observer WHERE observer_id = :observer_id";
			$stmt = $this->conn->prepare($sql);
			$stmt->bindParam(':observer_id', $observerId);
			$stmt->execute();
			$observerEmail = $stmt->fetchColumn();
			return $observerEmail;
		}
		public function getVolunteerName($volunteerId) 
		{
			$sql = "SELECT volunteer_name FROM volunteer WHERE volunteer_id = :volunteer_id";
			$stmt = $this->conn->prepare($sql);
			$stmt->bindParam(':volunteer_id', $volunteerId);
			$stmt->execute();
			$volunteerName = $stmt->fetchColumn();
			return $volunteerName;
		}
		
		public function getVolunteerEmail($volunteerId)
		{
			$sql = "SELECT volunteer_email FROM volunteer WHERE volunteer_id = :volunteer_id";
			$stmt = $this->conn->prepare($sql);
			$stmt->bindParam(':volunteer_id', $volunteerId);
			$stmt->execute();
			$volunteerEmail = $stmt->fetchColumn();
			return $volunteerEmail;
		}
		public function increaseChartData($label)
		{
			$query = "UPDATE chart_data SET data = data + 1 WHERE label = :label";
			$stmt = $this->conn->prepare($query);
			$stmt->bindParam(':label', $label);
			$stmt->execute();
		}
	
		public function decreaseChartData($label)
		{
			$query = "UPDATE chart_data SET data = GREATEST(data - 1, 0) WHERE label = :label";
			$stmt = $this->conn->prepare($query);
			$stmt->bindParam(':label', $label);
			$stmt->execute();
		}
	
		public function fetchChartData()
		{
			$query = "SELECT label, data FROM chart_data";
			$stmt = $this->conn->prepare($query);
			$stmt->execute();
			$chartData = $stmt->fetchAll(PDO::FETCH_ASSOC);
	
			$data = array();
			foreach ($chartData as $row) {
				$data[$row['label']] = $row['data'];
			}
	
			return $data;
		}
	}
	
	