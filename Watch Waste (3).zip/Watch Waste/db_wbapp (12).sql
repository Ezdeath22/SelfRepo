-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 23, 2024 at 06:01 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_wbapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `chart`
--

CREATE TABLE `chart` (
  `id` int(11) NOT NULL,
  `month` varchar(255) NOT NULL,
  `data` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `chart`
--

INSERT INTO `chart` (`id`, `month`, `data`) VALUES
(1, 'January', 40),
(2, 'February', 60),
(3, 'March', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(11) NOT NULL,
  `admin_firstname` varchar(255) NOT NULL,
  `admin_lastname` varchar(255) NOT NULL,
  `admin_password_hash` varchar(100) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_gender` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_firstname`, `admin_lastname`, `admin_password_hash`, `admin_email`, `admin_gender`) VALUES
(13, 'John Mark', 'Aposaga', '$2y$10$M.TjTKgR5sCdvGVbV2TtneiYHp34HF8qcNcg/GTJLBhW69Awh83US', 'ezdeath0622@gmail.com', 'male');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `user_id` int(8) UNSIGNED NOT NULL,
  `user_lastname` varchar(180) NOT NULL DEFAULT '',
  `user_firstname` varchar(180) NOT NULL DEFAULT '',
  `user_email` varchar(180) NOT NULL DEFAULT '',
  `user_password_hash` varchar(255) NOT NULL DEFAULT '',
  `user_area` varchar(180) NOT NULL DEFAULT '',
  `user_status` int(1) NOT NULL DEFAULT 0,
  `user_token` varchar(255) NOT NULL DEFAULT '',
  `user_access` varchar(255) NOT NULL DEFAULT '',
  `user_gender` varchar(255) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`user_id`, `user_lastname`, `user_firstname`, `user_email`, `user_password_hash`, `user_area`, `user_status`, `user_token`, `user_access`, `user_gender`) VALUES
(7, 'Aposaga', 'JM', 'jmaposaga@gmail.com', '$2y$10$Sxu8/B07DlpDlseuQ13FPuu5KoRNzznr41e.ydTrhjx/R0t8XYfQy', 'Zone 1', 1, '', 'Volunteer', 'male'),
(6, 'Aposaga', 'JM', 's2201136@usls.edu.ph', '$2y$10$yahNC5cJjdRhLJt8lwSo8.dimXlEKKZDkqDvS5VbpcS9V8yzC8AY6', '', 1, '', 'Volunteer', 'male');

-- --------------------------------------------------------

--
-- Table structure for table `zones`
--

CREATE TABLE `zones` (
  `zone_id` int(11) NOT NULL,
  `zone_name` varchar(50) NOT NULL,
  `description` varchar(999) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `zones`
--

INSERT INTO `zones` (`zone_id`, `zone_name`, `description`) VALUES
(1, 'DC 1 Subdivision', 'DC 1 Subdivision is known for its residential charm, featuring pristine parks and clean streets, creating a serene living environment.\r\nDC 1 Subdivision is located in Barangay Alijis, Bacolod City'),
(2, 'DC 2 Subdivision', ' DC 2 Subdivision offers a harmonious mix of residential and commercial spaces, maintaining cleanliness in both sectors for a well-rounded community. Regent Pearl Homes, DC-2, located in Barangay Alijis Bacolod City'),
(3, 'DC 3 Subdivision', 'DC 3 Subdivision provides a blend of housing options within well-maintained greenery, emphasizing a clean and tranquil atmosphere. \r\nDC 3 Subdivision, located in Barangay Alijis, Bacolod City'),
(4, 'Terra Nova Subdivision', 'Terra Nova Subdivision stands out with its family-friendly atmosphere, incorporating designated clean zones and recreational spaces, ensuring residents enjoy a consistently pleasant and tidy living experience. Terra Nova Subdivision. situated in Barangay Alijis, Bacolod City');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chart`
--
ALTER TABLE `chart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `zones`
--
ALTER TABLE `zones`
  ADD PRIMARY KEY (`zone_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chart`
--
ALTER TABLE `chart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `user_id` int(8) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `zones`
--
ALTER TABLE `zones`
  MODIFY `zone_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
