<?php
include_once 'classes/class.admin.php'; // Include the class file

$admin = new admin(); // Instantiate the admin class
$admin_id = 1; // Replace with the actual admin ID you want to get the gender for

$admin_gender = $admin->get_admin_gender($admin_id);

    if (isset($_GET['error'])) {
        $error = $_GET['error'];
        switch ($error) {
            case 'invalidemail':
                $errorMessage = 'Invalid email format.';
                break;
            case 'emailtaken':
                $errorMessage = 'Email is already taken. Please use a different email.';
                break;
            case 'registrationfailed':
                $errorMessage = 'Registration failed. Please try again.';
                break;
            // Add more cases if needed
            default:
                $errorMessage = 'An unknown error occurred.';
        }
        echo '<script>alert("' . $errorMessage . '");</script>';
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Apply for Admin</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Assistant&display=swap" rel="stylesheet">
    <style>
        body {
            background-image: url('image/trash1.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            font-family: 'Assistant', sans-serif;
            margin: 0;
            padding: 0;
        }

        #brand-block {
            text-align: center;
            padding: 20px;
        }

      
     
        .input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            box-sizing: border-box;
        }

        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            box-sizing: border-box;
            background-color: #32373d;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        a {
            color: #32373d;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }

        #form-block {
  border-radius: 5px;
  background: rgba(255, 255, 255, 0.6);
  padding: 20px;
    width: 80%;
    margin: 0 auto;

}


        h3 {
            font-size: 24px;
            color: black;
            text-align: center;
            margin-bottom: 20px;
        }

        #form-block #form-block-half{
    width: 45%;
    float: left;
    padding: 20px;
}
#button-block{
    width: 95%;
    padding: 20px;
    text-align: right;
}
    </style>
</head>

<body>
<div id="brand-block">

</div>

<div id="form-block">
    <h3>Please Provide the Required Information</h3>
    <center>
        <img src="watchwaste.png" alt="Watch Waste" style="width: 150px; height: auto;">
    </center>
    <form method="POST" action="processes/process.admin.php?action=new">
        <div id="form-block-half">
            <label for="fname">First Name</label>
            <input type="text" id="fname" class="input" name="firstname" placeholder="Your name..">

            <label for="lname">Last Name</label>
            <input type="text" id="lname" class="input" name="lastname" placeholder="Your last name..">
            
          
            
            <!-- Gender Selection -->
            <label for="gender">Gender</label>
            <div>
                <input type="radio" id="male" name="gender" value="male">
                <label for="male">Male</label>
                
                <input type="radio" id="female" name="gender" value="female">
                <label for="female">Female</label>
            </div>
        </div>
        <div id="form-block-half">

        <label for="email">Email</label>
            <input type="email" id="email" class="input" name="email" placeholder="Your email..">
            <label for="password">Password</label>
            <input type="password" id="password" class="input" name="password" placeholder="Enter password.." pattern=".{8,}" required title="Password must be at least 8 characters long">

            <label for="confirmpassword">Confirm Password</label>
            <input type="password" id="confirmpassword" class="input" name="confirmpassword" placeholder="Confirm password..">

        </div>
        <div id="button-block">
            <input type="submit" value="Register">
        </div>
        <p>Have Account? Please <a href="login.php">Sign In</a></p>
    </form>
</div>

</body>

</html>