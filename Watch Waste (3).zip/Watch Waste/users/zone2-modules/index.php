<?php
include 'db_connection.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['increase']) || isset($_POST['decrease'])) {
        $month = $_POST['month'];
        $change = (isset($_POST['increase'])) ? $_POST['changeValue'] : -$_POST['changeValue'];

        // Ensure that data won't go below zero
        $sql = "UPDATE chart SET data = GREATEST(0, data + ?) WHERE month = ?";
        $stmt = $conn->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("ss", $change, $month);
            $stmt->execute();

            if ($stmt->errno) {
                die("Query failed: " . $stmt->error);
            }

            $stmt->close();
        } else {
            die("Prepared statement error: " . $conn->error);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Bar Chart Example</title>
    <link href="https://fonts.googleapis.com/css2?family=Assistant&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<h3> Total Clean Chart </h3>
<?php
$sql = "SELECT * FROM chart";
$result = $conn->query($sql);

if (!$result) {
    die("Query failed: " . $conn->error);
}

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[$row['month']] = $row['data'];
}

$months = array_keys($data);
$values = array_values($data);

// Specify different colors for each month
$colors = [
    'rgba(255, 99, 132, 0.2)',   // Red for January
    'rgba(54, 162, 235, 0.2)',   // Blue for February
    'rgba(75, 192, 192, 0.2)'    // Green for March
];
$borderColors = [
    'rgba(255, 99, 132, 1)',
    'rgba(54, 162, 235, 1)',
    'rgba(75, 192, 192, 1)'
];
?>


<canvas id="myChart" width="400" height="200"></canvas>

<script>
    var ctx = document.getElementById('myChart').getContext('2d');

    var myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?= json_encode($months) ?>,
            datasets: [{
                label: 'Data',
                data: <?= json_encode($values) ?>,
                backgroundColor: <?= json_encode($colors) ?>,
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        }
    });
</script>

<center>
<form>
    <h3> For Volunteers </h3>
    <button type="submit" name="">I Alraedy Clean it</button>
    <h3> For Observers </h3>
    <button type="submit" name="">I Already Observe it</button>
</center>
</body>
</html>
