<?php
include '../classes/class.user.php';

// Assuming you have a database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "db_wbapp";

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'reply':
        process_reply();
        break;
}

function process_reply()
{
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $sender = isset($_POST['sender']) ? $_POST['sender'] : '';
        $replyMessage = isset($_POST['reply']) ? $_POST['reply'] : '';

        // Assuming you have a session or user authentication to get the user's ID
        $userId = 1; // Replace with the actual user ID

        // Determine which table to insert the reply based on the sender
        $tableName = ($sender == 'Admin') ? 'tbl_admin' : 'tbl_users';

        // Insert the reply into the corresponding table
        global $conn;
        $stmt = $conn->prepare("INSERT INTO $tableName ({$sender}_msg, user_id, message_date) VALUES (?, ?, CURRENT_TIMESTAMP)");
        $stmt->bind_param("si", $replyMessage, $userId);

        if ($stmt->execute()) {
            echo '<script>alert("Reply submitted successfully.");</script>';
        } else {
            echo '<script>alert("Error submitting reply.");</script>';
        }

        $stmt->close();
    }
}

// Close the database connection
$conn->close();
?>
