    <?php
    include '../classes/class.user.php';

    $action = isset($_GET['action']) ? $_GET['action'] : '';

    switch($action){
        case 'new':
            create_new_user();
        break;
        case 'update':
            update_user();
        break;
        case 'deactivate':
            deactivate_user();
        break;
        case 'delete':
            delete_user();
        break;
        case 'reply':
            process_reply();
            break;
    }
    function delete_user(){
        $user = new User();
        $user_id = $_POST['userid'];
        $result = $user->delete_user($user_id);
        if($result){
            // Redirect or display a message after successful deletion
            header('location: ../index.php?message=Account%20deleted%20successfully');
        } else {
            // Handle deletion failure
            // You can display an error message or redirect to an error page
            echo "Failed to delete account";
        }
    }
    function create_new_user()
    {
        $user = new User();
        $email = isset($_POST['email']) ? $_POST['email'] : '';
        $lastname = isset($_POST['lastname']) ? ucwords($_POST['lastname']) : '';
        $firstname = isset($_POST['firstname']) ? ucwords($_POST['firstname']) : '';
        $access = isset($_POST['access']) ? ucwords($_POST['access']) : '';
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        $confirmpassword = isset($_POST['confirmpassword']) ? $_POST['confirmpassword'] : '';
        $usergender = isset($_POST['gender']) ? $_POST['gender'] : ''; // Add this line to fetch gender


        // Check if 'email' is set in $_POST
        if (empty($email)) {
            echo '<script>alert("Email is required.");</script>';
            // Handle the error as needed
            return;
        }

        // Check if the passwords match
        if ($password !== $confirmpassword) {
            echo '<script>alert("Passwords do not match.");</script>';
            // Handle the error as needed
            return;
        }

        // Hash the password using bcrypt
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Check if the email already exists
        if ($user->email_exists($email)) {
            echo '<script>alert("Email is already taken. Please choose a different email.");</script>';
            // You may also redirect the user or handle this situation differently if needed
        } else {
            // Email is not taken, proceed with user creation
            $result = $user->new_user($email, $hashedPassword, $lastname, $firstname, $access, $usergender);
            if ($result) {
                $id = $user->get_user_id($email);
                header('location: ../index.php?page=settings&subpage=users&action=profile&id=' . $id);
            }
        }
    }

    function hash_password($password) {
        // Use a secure hashing algorithm like bcrypt with a high cost factor
        return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
    }

    function update_user(){
        $user = new User();
        $user_id = $_POST['userid'];
        $lastname = ucwords($_POST['lastname']);
        $email = ucwords($_POST['email']);
        $firstname = ucwords($_POST['firstname']);
        $access = ucwords($_POST['access']);
        $area = ucwords($_POST['area']);
        $usergender = ucwords($_POST['gender']);
        
        $result = $user->update_user($lastname, $email, $firstname,$access, $area, $user_id, $usergender);
        if($result){
            header('location: ../index.php?page=settings&subpage=users&action=profile&id='.$user_id);
        }
    }

    function process_reply()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $sender = isset($_POST['sender']) ? $_POST['sender'] : '';
            $replyMessage = isset($_POST['reply']) ? $_POST['reply'] : '';
    
            // Assuming you have a session or user authentication to get the user's ID
            $userId = 1; // Replace with the actual user ID
    
            // Determine which table to insert the reply based on the sender
            $tableName = ($sender == 'Admin') ? 'tbl_admin' : 'tbl_users';
    
            // Insert the reply into the corresponding table
            global $conn;
            $stmt = $conn->prepare("INSERT INTO $tableName ({$sender}_msg, user_id, message_date) VALUES (?, ?, CURRENT_TIMESTAMP)");
            $stmt->bind_param("si", $replyMessage, $userId);
    
            if ($stmt->execute()) {
                echo '<script>alert("Reply submitted successfully.");</script>';
            } else {
                echo '<script>alert("Error submitting reply.");</script>';
            }
    
            $stmt->close();
        }
    }

    function deactivate_user(){
        $user = new User();
        $user_id = $_POST['userid']; 
        $result = $user->deactivate_user($user_id);
        if($result){
            header('location: ../index.php?page=settings&subpage=users&action=profile&id='.$user_id);
        }
        function delete_user(){
            $user = new User();
            $user_id = $_POST['userid'];
            $result = $user->delete_user($user_id);
            if($result){
                // Redirect or display a message after successful deletion
                header('location: ../index.php?message=Account%20deleted%20successfully');
            } else {
                // Handle deletion failure
                // You can display an error message or redirect to an error page
                echo "Failed to delete account";
            }
        }
        
    }
