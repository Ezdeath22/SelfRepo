<?php
include '../classes/class.admin.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';

switch($action){
	case 'new':
        create_new_admin();
	break;
    case 'update':
        update_admin();
	break;
    case 'deactivate':
        deactivate_admin();
	break;
    case 'delete':
        delete_admin();
	break;
    case 'reply':
        process_reply();
        break;
}
function create_new_admin(){
        $admin = new admin();
        $adminemail = isset($_POST['email']) ? $_POST['email'] : '';
        $adminlastname = isset($_POST['lastname']) ? ucwords($_POST['lastname']) : '';
        $adminfirstname = isset($_POST['firstname']) ? ucwords($_POST['firstname']) : '';
        $adminpassword = isset($_POST['password']) ? $_POST['password'] : '';
        $adminconfirmpassword = isset($_POST['confirmpassword']) ? $_POST['confirmpassword'] : '';
        
        // Check if 'email' is set in $_POST
        if (empty($adminemail)) {
            echo '<script>alert("Email is required.");</script>';
            // Handle the error as needed
            return;
        }
    
        // Check if the email already exists
        if ($admin->email_exists($adminemail)) {
            echo '<script>alert("Email is already taken. Please choose a different email.");</script>';
            // You may also redirect the user or handle this situation differently if needed
        } else {
            // Email is not taken, proceed with user creation
            $result = $admin->new_admin($adminemail, $adminpassword, $adminlastname, $adminfirstname);
            if ($result) {
                $id = $admin->get_admin_id($adminemail);
                header('location: ../index.php?page=settings&subpage=admin&action=profile&id=' . $id);
            }
        }
    }
    
    function update_admin(){
        $admin = new admin();
        $admin_id = $_POST['adminid'];
        $adminlastname = ucwords($_POST['lastname']);
        $adminemail = ucwords($_POST['email']);
        $adminfirstname = ucwords($_POST['firstname']);
       
       
        
        $result = $admin->update_admin($adminlastname, $adminemail, $adminfirstname,$admin_id);
        if($result){
            header('location: index.php?page=settings&subpage=admin&action=profile&id='.$admin_id);
        }
    }
    
 
    
    function deactivate_admin(){
        $admin = new admin();
        $admin_id = $_POST['adminid']; 
        $result = $admin->deactivate_admin($admin_id);
        if($result){
            header('location: ../index.php?page=settings&subpage=admin&action=profile&id='.$admin_id);
        }
    }