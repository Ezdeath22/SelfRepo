<div id="subcontent">
    <table id="data-list">
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Access Level</th>
            <th>Email</th>
            <th>Designated Area</th>
        </tr>
        <?php
        $count = 1;

        if ($user->list_users() != false) {
            foreach ($user->list_users() as $value) {
                extract($value);

                // Assuming $user_area is the variable indicating the area
                if ($user_area == 'Zone 1') {
                    ?>
                    <tr>
                        <td><?php echo $count; ?></td>
                        <td><a style="color: black;" href="index.php?page=settings&subpage=users&action=profile&id=<?php echo $user_id;?>"><?php echo $user_lastname.', '.$user_firstname;?></a></td>
                        <td><?php echo $user_access; ?></td>
                        <td><?php echo $user_email; ?></td>
                        <td><?php echo $user_area; ?></td>
                    </tr>
                    <?php
                    $count++;
                }
            }

            if ($count == 1) {
                // No users found in Zone 1
                echo '<tr><td colspan="5">No users found in Zone 1.</td></tr>';
            }
        } else {
            echo "<tr><td colspan='5'>No Record Found.</td></tr>";
        }
        ?>
<a style="color: black; font-weight: bold;">Click your Name to Update your Details</a>
    </table>
    
</div>

