<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Watch Waste App</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
     
        }

        #content, #target-barangay {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
       

            
        }

        #watch-waste-info {
            background-color: #f8f9fa;
            padding: 20px;
            text-align: left;
            border-radius: 10px;
        }

        h2 {
            color: #007bff;
        }
        p{
            color: black;
            font-size: 16px;
        }

        .image {
    max-width: 200px; /* Adjust the width as per your preference */
    width: 100%;
    height: auto;
    border-radius: 8px;
    margin-top: 20px;
}

    </style>
</head>
<body>

    <br>
    <br>
    <br>
    <br>
    
<div id="content">
        <div id="watch-waste-info">
            <h2>Story about Watch Waste</h2>
            <p>
                Watch Waste is an innovative web app designed to empower users in monitoring cleanliness levels of various zones or locations.
                With user-friendly features, it allows you to easily check and assess whether a particular area is pristine or in need of attention,
                fostering a community-driven approach towards maintaining cleanliness and hygiene. Stay informed and contribute to a cleaner environment
                with Watch Waste.
            </p>
            <p>
                Our app provides real-time updates on the status of different zones, helping you make informed decisions about your surroundings.
                Whether you're a resident, business owner, or local authority, Watch Waste facilitates collaboration in creating and sustaining a
                healthier community for everyone. Join us in the mission to keep our neighborhoods clean and beautiful.
            </p>
            <center>
            <img src="panaadcreek.jpg" alt="Image 1" class="image">
            <img src="panaadcreek2.jpg" alt="Image 2" class="image">
</center>
        </div>
    </div>

    <div id="target-barangay">
        <h2>Our Target Barangay: Brgy Alijis</h2>
        <p>
            "Barangay Alijis is our selected place to conduct research. The Barangay Captain, Ebony Dela Vega, says that the primary problem here in Barangay Alijis is waste. That's why John Mark Aposaga and Hanz Justin Deocampo created an app called Watch Waste App to reduce the possibility of getting more waste in Barangay Alijis."
        </p>
    <center>
        <img src="barangay.jpg" alt="Image 4" class="image">
        <img src="ebony.jpg" alt="Image 3" class="image">
</center>
    </div>

</body>
</html>

</body>
</html>
