<?php
date_default_timezone_set("Asia/Manila");

if (!defined('DB_SERVER')) {
    define('DB_SERVER', 'localhost');
    define('DB_USERNAME', 'root');
    define('DB_PASSWORD', '');
    define('DB_DATABASE', 'db_wbapp');
}

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
