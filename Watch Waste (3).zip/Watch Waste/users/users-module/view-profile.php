<h3>Provide the Required Information</h3>
<div id="form-block">
<form method="POST" action="processes/process.user.php?action=update">
        <div id="form-block-half">
            <label for="fname">First Name</label>
            <input type="text" id="fname" class="input" name="firstname" value="<?php echo $user->get_user_firstname($id);?>" placeholder="Your name..">

            <label for="lname">Last Name</label>
            <input type="text" id="lname" class="input" name="lastname" value="<?php echo $user->get_user_lastname($id);?>" placeholder="Your last name..">

            <label for="access">Access Level</label>
            <select id="access" name="access">
              <option value="volunteer" <?php if($user->get_user_access($id) == "Volunteer"){ echo "selected";};?>>Volunteer</option>
              <option value="observer" <?php if($user->get_user_access($id) == "Observer"){ echo "selected";};?>>Observer</option>
              </select>
        </div>
        <div id="form-block-half">
            <label for="status">Account Status</label>
            <select id="status" name="status">
              <option <?php if($user->get_user_status($id) == "0"){ echo "selected";};?>>Deactivated</option>
              <option <?php if($user->get_user_status($id) == "1"){ echo "selected";};?>>Active</option>
            </select>
            <label for="email">Email</label>
            <input type="email" id="email" class="input" name="email" value="<?php echo $user->get_user_email($id);?>" placeholder="Your email..">
            <label for="area">Your Designated Area</label>
            <select id="area" name="area">
              <option value="Zone 1" <?php if($user->get_user_area($id) == "Zone 1 "){ echo "selected";};?>>Zone 1</option>
              <option value="Zone 2" <?php if($user->get_user_area($id) == "Zone 2"){ echo "selected";};?>>Zone 2</option>
              <option value="Zone 3" <?php if($user->get_user_area($id) == "Zone 3 "){ echo "selected";};?>>Zone 3</option>
              <option value="Zone 4" <?php if($user->get_user_area($id) == "Zone 4"){ echo "selected";};?>>Zone 4</option>
              </select>
            
            <input type="hidden" id="userid" name="userid" value="<?php echo $id;?>"/>
          
            <?php
            if($user->get_user_status($id) == "1"){
              ?>
                
              <?php
            }else{
            ?>
                <a href="#">Activate Account</a>
            <?php
            }
            ?>
            
        </div>
        <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
        <div id="button-block">
        <input type="submit" value="Update">
        </div>
        
</form>
<form method="POST" action="processes/process.user.php?action=delete">
    <input type="hidden" id="userid" name="userid" value="<?php echo $id; ?>"/>
    <div id="button-block">
        <input type="submit" value="Delete Account" onclick="return confirm('Are you sure you want to delete your account? This action cannot be undone.');">
    </div>
</form>
</div>
