<?php
/* include the class file (global - within application) */
include_once 'classes/class.user.php';
include 'config/config.php';

$page = (isset($_GET['page']) && $_GET['page'] != '') ? $_GET['page'] : '';
$subpage = (isset($_GET['subpage']) && $_GET['subpage'] != '') ? $_GET['subpage'] : '';
$action = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : '';
$id = (isset($_GET['id']) && $_GET['id'] != '') ? $_GET['id'] : '';

$user = new User(); // Instantiate the User class here

if(!$user->get_session()){
	header("location: login.php");
}
$user_id = $user->get_user_id($_SESSION['user_email']);
date_default_timezone_set("Asia/Manila");

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include 'config/config.php';  // Adjust the path as per your directory structure

try {
    // Create a PDO instance
    $pdo = new PDO("mysql:host=" . DB_SERVER . ";dbname=" . DB_DATABASE, DB_USERNAME, DB_PASSWORD);

    // Set the PDO error mode to exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Check if the form is submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Check if 'selected_zone' is set in $_POST
        if (isset($_POST['selected_zone'])) {
            $selectedZone = $_POST['selected_zone'];

            // Perform any necessary validation or sanitation on $selectedZone

            // Assuming you have the user ID from the session
            $user_id = isset($_SESSION['user_email']) ? $user->get_user_id($_SESSION['user_email']) : null;

            // Check if $user_id is not null before proceeding
            if ($user_id !== null) {
                // Use a prepared statement to update the user_area in the tbl_users table
                $stmt = $pdo->prepare("UPDATE tbl_users SET user_area = :selectedZone WHERE user_id = :user_id");
                $stmt->bindParam(':selectedZone', $selectedZone);
                $stmt->bindParam(':user_id', $user_id);
                $stmt->execute();
            } else {
                // Handle the case where $user_id is null (e.g., user is not logged in)
                echo "User not logged in or session data missing.";
            }
        } else {
            // Handle the case where 'selected_zone' is not set in $_POST
            echo "Selected zone not provided in the form.";
        }
    }
} catch (PDOException $e) {
    // Handle database connection errors
    echo "Connection failed: " . $e->getMessage();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Watch Waste</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Assistant&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/custom.css?<?php echo time();?>">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="../css/style.css">
        <style>
    #content {
        margin: 50px;
    }



               
</style>
</head>
<body>
<div id="header" style="background-color: #32373d; padding: 50px; text-align: center; margin: 0; color: white; margin-right: 0;">
    <h1 style="margin: 0;"><img src="watchwaste.png" style="width: 200px; height: auto; position: relative; top: -110px;"> </h1>
</div>
<div class="wrapper d-flex align-items-stretch">

			<nav id="sidebar">
				<div class="custom-menu">
					<button type="button" id="sidebarCollapse" class="btn btn-primary">
	        </button>
        </div>
        <div id="header">
     <a> &nbsp; WELCOME TO  <img src="watchwaste.png" style="width: 100px; height: auto; position: relative; top: -15px;"> <a>
    </div>
    <br>
	  		<div class="img bg-wrap text-center py-4" style="background-image: url(../image/trash1.jpg);">
	  			<div class="user-logo">
                  <div class="img">
    <img src="<?php echo ($user->get_user_gender($user_id) == 'male') ? '../image/male.png' : '../image/female.png'; ?>" style="width: 100px; height: 100px; margin-right: 10px;">
</div>
	  				<h3>  <?php echo $user->get_user_lastname($user_id).', '.$user->get_user_firstname($user_id);?>
    </h3>
	  			</div>
	  		</div>
        <ul class="list-unstyled components mb-5">
          <li class="active">
            <a href="index.php"><span class="fa fa-home mr-3"></span> Home</a>
          </li>
         
<ul class="list-unstyled components mb-5">
    
    <li>
        <a href="index.php?page=settings">
            <span class="fa fa-cog mr-3"></span> Settings
        </a>
    </li>
    <li>
        <a href="index.php?page=aboutus">
            <span class="fa fa-support mr-3"></span> About Us
        </a>
    </li>
    <li>
        <a href="logout.php">
            <span class="fa fa-sign-out mr-3"></span> Sign Out
        </a>
    </li>
</ul>


    	</nav>
       

  <div id="content">
<?php
    switch($page){
        case 'settings':
            require_once 'settings-module/index.php';
            break; 
        case 'zone1':
            require_once 'zone1-modules/index.php';
            break; 
        case 'zone2':
            require_once 'zone2-modules/index.php';
            break; 
        case 'zone3':
            require_once 'zone3-modules/index.php';
            break; 
        case 'zone4':
            require_once 'zone4-modules/index.php';
            break;
            case 'aboutus':
                // Include the messages content file
                require_once 'aboutus.php';
                break;
        default:
            // Assuming main.php will be your main content file
            require_once 'index.php';
            break; 
    }
   

    
    if ($page !== 'messages' && !in_array($page, ['zone1', 'zone2', 'zone3', 'zone4', 'settings', 'aboutus'])) {
        // Display the additional content only if not on Zone 1, Zone 2, Zone 3, or Zone 4
        for ($zoneId = 1; $zoneId <= 4; $zoneId++) {
            $zoneName = $user->getZoneName($zoneId);
            $zoneDescription = $user->getZoneDescription($zoneId);
    
            $imgSrc = "";
            $zoneLink = "";
    
            switch ($zoneId) {
                case 1:
                    $imgSrc = "DC1.jpg";
                    $zoneLink = "index.php?page=zone1";
                    break;
                case 2:
                    $imgSrc = "DC2.jpg";
                    $zoneLink = "index.php?page=zone2";
                    break;
                case 3:
                    $imgSrc = "DC3.jpg";
                    $zoneLink = "index.php?page=zone3";
                    break;
                case 4:
                    $imgSrc = "Terra Nova.jpg";
                    $zoneLink = "index.php?page=zone4";
                    break;
            }
    ?>
    
            <!-- HTML code with dynamic data -->
       <!-- HTML code with dynamic data -->
       <div class="row featurette">
    <?php if ($zoneId == 1 || $zoneId == 3) : ?>
        <!-- Zone 1 and Zone 3 on the right side -->
        <div class="col-md-5 featurette-image-container">
            <a href="<?php echo $zoneLink; ?>">
                <img src="<?php echo $imgSrc; ?>" alt="Image <?php echo $zoneId; ?>" class="featurette-image img-fluid mx-auto">
            </a>
        </div>
        <div class="col-md-7">
            <h2 class="featurette-heading fw-normal lh-1"><?php echo $zoneName; ?><br><br><br>
                <p class="lead"><?php echo $zoneDescription; ?></p>
                <div id="button-block">
                    <form method="post" action="">
                        <button type="submit" name="selected_zone" value="Zone <?php echo $zoneId; ?>" <?php if($user->get_user_area($id) == "Zone $zoneId"){ echo "class='active'"; }?>>Join Zone <?php echo $zoneId; ?></button>
                    </form>
                </div>
            </div>
    <?php else : ?>
        <!-- Zone 2 and Zone 4 on the left side -->
        <div class="col-md-7">
            <h2 class="featurette-heading fw-normal lh-1"><?php echo $zoneName; ?><br><br><br>
                <p class="lead"><?php echo $zoneDescription; ?></p>
                <div id="button-block">
                    <form method="post" action="">
                        <?php if ($zoneId == 2 || $zoneId == 4) : ?>
                            <button type="submit" name="selected_zone" value="Zone <?php echo $zoneId; ?>" <?php if($user->get_user_area($id) == "Zone $zoneId"){ echo "class='active'"; }?>>Join Zone <?php echo $zoneId; ?></button>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
            <div class="col-md-5 featurette-image-container">
                <a href="<?php echo $zoneLink; ?>">
                    <img src="<?php echo $imgSrc; ?>" alt="Image <?php echo $zoneId; ?>" class="featurette-image img-fluid mx-auto">
                </a>
            </div>
    <?php endif; ?>
</div>
<hr style="height: 20px; background-color: #32373d;"> <!-- Add a horizontal line after each zone description -->

<?php
    }
}
?>

    
    

</div>
</div>
<script src="../js/jquery.min.js"></script>
    <script src="../js/popper.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/main.js"></script>
<script src="../jscript/script.js"></script>
</body>
</html>
